<template>
  <v-container>
    <v-row>
      <v-col>
        <v-text-field
            v-model="sourcecity"
            :rules="sourceCityRules"
            label="Where are you flying from?"
            required
          ></v-text-field>
        <v-btn type="submit" color="warning" @click="fetchFlightDetails()" dark>Submit</v-btn>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="4" v-for="item in cities" v-bind:key="item.city">
        <city-info-card :cityData="item" />
      </v-col>
      
    </v-row>
  </v-container>
</template>

<script>
import accuweather from "./utils/accuweather";
import checkFlights from "./utils/checkFlights";
import CityInfoCard from './CityInfoCard'

export default {
  name: "WeatherAndFlightInfo",
  components:{CityInfoCard},

  data: () => ({
    sourcecity: '',
    destinationcity: '',
    modal: false,
    sourceCityRules: [
        sourceCityRule => !!sourceCityRule || 'Source city is required',
        sourceCityRule => sourceCityRule.length <= 10 || 'Source city(IATA code) must be equal to 3 characters',
      ],
    cities: [
      {
        city: "Amsterdam",
        countryCode: "NL",
        airportCode: 'AMS',
        country: "Netherlands",
        weather: null,
        flights: []
      },

      {
        city: "Budapest",
        countryCode: "HU",
        airportCode: "BUD",
        country: "Hungary",
        weather: null,
        flights: []
      },
      {
        city: "Madrid",
        countryCode: "ES",
        airportCode: "MAD",
        country: "Spain",
        weather: null,
        flights: []
      }
    ]
  }),
  created: function() {
    this.fetchWeatherDetails();
  },
  methods: {
    async fetchWeatherDetails() {
      this.cities.forEach(async (item, index) => {
        const res = await accuweather.getCityWeatherForcast(
          item.city,
          item.countryCode
        );
        this.cities[index].weather = res;
      });
    },
    async fetchFlightDetails() {
      this.cities.forEach(async (item, index) => {
        const flightsRes = await checkFlights.checkFlights(
          item.airportCode,
          this.sourcecity
        );
        this.cities[index].flights = flightsRes;
      });
    }
  }
};
</script>
<style scoped>
  .tempFont {
    font-size: 2rem;
  }
</style>