export default {
    async checkFlights(airportCode, sourcecity) {
        sourcecity = sourcecity ? sourcecity : '';
        let destinationcity = airportCode ? airportCode : '';
        let one_for_city = 1;
        let partner = 'picky';
        let date_from = new Date();
        let formattedDateFrom = ('0' + date_from.getDate()).slice(-2) + '%2F'
             + ('0' + (date_from.getMonth()+1)).slice(-2) + '%2F'
             + date_from.getFullYear();
        
        let date_to = new Date();
        let date_tomorrow = new Date(date_to)
        date_tomorrow = date_tomorrow.setDate(date_tomorrow.getDate() + 2);
        let final_date_tomorrow = new Date(date_tomorrow);
        let formattedDateTo = ('0' + final_date_tomorrow.getDate()).slice(-2) + '%2F'
                + ('0' + (final_date_tomorrow.getMonth()+1)).slice(-2) + '%2F'
                + final_date_tomorrow.getFullYear();

        const flightDetails = await axios.get('https://api.skypicker.com/flights?fly_from='+sourcecity+'&fly_to='+destinationcity+'&date_from='+
        formattedDateFrom+'&date_to='+formattedDateTo+'&one_for_city='+one_for_city+'&partner='+partner);
        let allFlightDetails = flightDetails.data.data;
        console.log(allFlightDetails)
        return allFlightDetails;
    }
}
import axios from 'axios';