export default {
    async getLocationByCityAndCountry(city,countryCode){
        const res = await axios.get(
          `http://dataservice.accuweather.com/locations/v1/cities/${countryCode}/search`,
          {
            params: {
              q: city,
              apikey: "jUOlMlgvV3hMhPO8ew8adB8dwyR8sT0m"
            }
          } 
        );

        if(res.data.length==0){
            return null;
        }

        if(res.data.length>1){
            res.data.sort((a,b)=>{a.Rank-b.Rank});
        }
        return  res.data[0].Key;

    },
    async getCityWeatherForcast(city,countryCode) {
        let test=true;
        if(test){
        const locationKey = await this.getLocationByCityAndCountry(city,countryCode);
        const res = await axios.get(`http://dataservice.accuweather.com/forecasts/v1/daily/1day/${locationKey}`,{
            params:{
                apikey: "jUOlMlgvV3hMhPO8ew8adB8dwyR8sT0m",
                metric: true,
                details: true
            }
        });
        const forecast =  res.data.DailyForecasts[0];
          return forecast;
        } 
        else{
            const forecast=    {
                "Date": "2020-08-08T07:00:00+02:00",
                "EpochDate": 1596862800,
                "Sun": {
                  "Rise": "2020-08-08T06:13:00+02:00",
                  "EpochRise": 1596859980,
                  "Set": "2020-08-08T21:18:00+02:00",
                  "EpochSet": 1596914280
                },
                "Moon": {
                  "Rise": "2020-08-08T23:27:00+02:00",
                  "EpochRise": 1596922020,
                  "Set": "2020-08-09T12:19:00+02:00",
                  "EpochSet": 1596968340,
                  "Phase": "WaningGibbous",
                  "Age": 19
                },
                "Temperature": {
                  "Minimum": {
                    "Value": 69,
                    "Unit": "F",
                    "UnitType": 18
                  },
                  "Maximum": {
                    "Value": 91,
                    "Unit": "F",
                    "UnitType": 18
                  }
                },
                "RealFeelTemperature": {
                  "Minimum": {
                    "Value": 68,
                    "Unit": "F",
                    "UnitType": 18
                  },
                  "Maximum": {
                    "Value": 93,
                    "Unit": "F",
                    "UnitType": 18
                  }
                },
                "RealFeelTemperatureShade": {
                  "Minimum": {
                    "Value": 68,
                    "Unit": "F",
                    "UnitType": 18
                  },
                  "Maximum": {
                    "Value": 89,
                    "Unit": "F",
                    "UnitType": 18
                  }
                },
                "HoursOfSun": 2.5,
                "DegreeDaySummary": {
                  "Heating": {
                    "Value": 0,
                    "Unit": "F",
                    "UnitType": 18
                  },
                  "Cooling": {
                    "Value": 15,
                    "Unit": "F",
                    "UnitType": 18
                  }
                },
                "AirAndPollen": [
                  {
                    "Name": "AirQuality",
                    "Value": 28,
                    "Category": "Good",
                    "CategoryValue": 1,
                    "Type": "Particle Pollution"
                  },
                  {
                    "Name": "Grass",
                    "Value": 0,
                    "Category": "Low",
                    "CategoryValue": 1
                  },
                  {
                    "Name": "Mold",
                    "Value": 0,
                    "Category": "Low",
                    "CategoryValue": 1
                  },
                  {
                    "Name": "Tree",
                    "Value": 0,
                    "Category": "Low",
                    "CategoryValue": 1
                  },
                  {
                    "Name": "Ragweed",
                    "Value": 0,
                    "Category": "Low",
                    "CategoryValue": 1
                  },
                  {
                    "Name": "UVIndex",
                    "Value": 5,
                    "Category": "Moderate",
                    "CategoryValue": 2
                  }
                ],
                "Day": {
                  "Icon": 4,
                  "IconPhrase": "Intermittent clouds",
                  "HasPrecipitation": false,
                  "ShortPhrase": "Hot with sun and clouds",
                  "LongPhrase": "Hot with intervals of clouds and sunshine; caution advised if doing strenuous activities outside",
                  "PrecipitationProbability": 3,
                  "ThunderstormProbability": 0,
                  "RainProbability": 3,
                  "SnowProbability": 0,
                  "IceProbability": 0,
                  "Wind": {
                    "Speed": {
                      "Value": 5,
                      "Unit": "mi/h",
                      "UnitType": 9
                    },
                    "Direction": {
                      "Degrees": 41,
                      "Localized": "NE",
                      "English": "NE"
                    }
                  },
                  "WindGust": {
                    "Speed": {
                      "Value": 14,
                      "Unit": "mi/h",
                      "UnitType": 9
                    },
                    "Direction": {
                      "Degrees": 41,
                      "Localized": "NE",
                      "English": "NE"
                    }
                  },
                  "TotalLiquid": {
                    "Value": 0,
                    "Unit": "in",
                    "UnitType": 1
                  },
                  "Rain": {
                    "Value": 0,
                    "Unit": "in",
                    "UnitType": 1
                  },
                  "Snow": {
                    "Value": 0,
                    "Unit": "in",
                    "UnitType": 1
                  },
                  "Ice": {
                    "Value": 0,
                    "Unit": "in",
                    "UnitType": 1
                  },
                  "HoursOfPrecipitation": 0,
                  "HoursOfRain": 0,
                  "HoursOfSnow": 0,
                  "HoursOfIce": 0,
                  "CloudCover": 68
                },
                "Night": {
                  "Icon": 36,
                  "IconPhrase": "Intermittent clouds",
                  "HasPrecipitation": false,
                  "ShortPhrase": "Partly cloudy and warm",
                  "LongPhrase": "Partly cloudy and warm",
                  "PrecipitationProbability": 3,
                  "ThunderstormProbability": 0,
                  "RainProbability": 3,
                  "SnowProbability": 0,
                  "IceProbability": 0,
                  "Wind": {
                    "Speed": {
                      "Value": 7,
                      "Unit": "mi/h",
                      "UnitType": 9
                    },
                    "Direction": {
                      "Degrees": 51,
                      "Localized": "NE",
                      "English": "NE"
                    }
                  },
                  "WindGust": {
                    "Speed": {
                      "Value": 11,
                      "Unit": "mi/h",
                      "UnitType": 9
                    },
                    "Direction": {
                      "Degrees": 51,
                      "Localized": "NE",
                      "English": "NE"
                    }
                  },
                  "TotalLiquid": {
                    "Value": 0,
                    "Unit": "in",
                    "UnitType": 1
                  },
                  "Rain": {
                    "Value": 0,
                    "Unit": "in",
                    "UnitType": 1
                  },
                  "Snow": {
                    "Value": 0,
                    "Unit": "in",
                    "UnitType": 1
                  },
                  "Ice": {
                    "Value": 0,
                    "Unit": "in",
                    "UnitType": 1
                  },
                  "HoursOfPrecipitation": 0,
                  "HoursOfRain": 0,
                  "HoursOfSnow": 0,
                  "HoursOfIce": 0,
                  "CloudCover": 59
                },
                "Sources": [
                  "AccuWeather"
                ],
                "MobileLink": "http://m.accuweather.com/en/nl/amsterdam/249758/daily-weather-forecast/249758?day=1&lang=en-us",
                "Link": "http://www.accuweather.com/en/nl/amsterdam/249758/daily-weather-forecast/249758?day=1&lang=en-us"
              };
          return forecast;
        }
        }
    

}
import axios from 'axios';